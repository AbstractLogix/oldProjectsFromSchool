//An instance of this class represents a Bit-String, a sequence of Binary Digits
//
//Class-Typical methods
// Constructors: create and initialize a new Bit-String instance
// Accessors   : return information on the state of a Bit-String instance
// Imagers     : return printable images of a Bit-String instance
//
//Some methods of the class implement typical operations on Bit-Strings
// magnitude() : interpretetion as an unsigned integer
// extension() : growing a Bit-String by appending another Binary-Digit
// complement(): 1's complement or bit-inversion of each Binary-Digit
// increment() : modifying a Bit-String so that its magnitude increases by 1
// negative()  : forming the 2's complement of a Bit-String
//
//Other methods manipulate an individual Binary-Digit of the Bit-String
// set()       : force a selected Binary-Digit to 1
// clear()     : force a selected Binary-Digit to 0
// complement(): invert a selected Binary-Digit (0 to 1, 1 to 0)
// assign()    : force a selected Binary-Digit to a given value
//
//**************** THIS CLASS HAS NO MUTATOR METHODS ****************
//Methods may return new instances derived from the invoking instance
// but leave the invoking instance (this) unchanged
//*******************************************************************
//
public class BitString
{
    //Class constants for the minimum and maximum lengths of any BitString
    public static final int MIN_LENGTH = 1;   //minimum length
    public static final int MAX_LENGTH = 32;  //maximum length

    //Instance Variable
    private BinaryDigit[] bits;   //bits[0] is least significant

    //CONSTRUCTORS ***********************************************************

    //Initializes a BitString of a given length with int value 0
    public BitString(int length)
    {
        this.bits = new BinaryDigit[length];
        for (int k = 0; k < this.bits.length; k++)
            this.bits[k] = BinaryDigit.ZRO;
    }

    //Initializes a BitString of a given length with a given int value
    public BitString(int length, int value)
    {
        this(length);
        int binarydigit = 0;
        int k = length -1;

        while(value > 0){
            binarydigit = value % 2;
            value = value / 2;
            bits [k] = BinaryDigit.bitValue(binarydigit);
            k--;
        }
        if ( false )
            throw new RuntimeException("Unsigned Overflow: " + value);
    }

    //Initializes a BitString of the given (parameter) length
    // from a given (parameter) image of '0' and '1' chars
    public BitString(int length, String image)
    {
        this(length);

        if (image.length() > length)
            throw new RuntimeException("Unsigned Overflow: " + image);

        //Missing Implementation
    }

    //ACCESSORS **************************************************************

    //Returns an array of all BinaryDigits of this BitString in the same order
    public BinaryDigit[] getBits()
    {
        return null;
    }

    //Returns the BinaryDigit of this BitString at a given index (parameter)
    public BinaryDigit getBit(int index)
    {
        return BinaryDigit.ZRO;
    }

    //Returns the number of BinaryDigits of this BitString
    public int length()
    {
        return 0;
    }

    //Returns a new BitString that is an exact copy of this BitString
    public BitString copy()
    {
        return null;
    }

    //BIT-STRING MANIPULATION ************************************************

    //Returns the unsigned integer interpretation of this BitString
    public int magnitude()
    {
        return 0;
    }

    //Returns a new BitString obtained by adding an additional BinaryDigit
    // to the high end of a copy of this BitString
    //Parameter extraBit provides the additional BinaryDigit to be added
    public BitString extension(BinaryDigit extraBit)
    {
        return null;
    }

    //Returns a new BitString whose BinaryDigits are the complements of
    // the BinaryDigits of this BitString
    public BitString complement()
    {
        return null;
    }

    //Returns a new BitString with the same length as this BitString,
    // and whose magnitude is 1 more than that of this BitString
    public BitString increment()
    {
        return null;
    }

    //Returns a new BitString with the same length as this BitString,
    // and whose value is the 2's-complement of this BitString
    public BitString negative()
    {
        return null;
    }

    //BIT MANIPULATION *******************************************************

    //Returns a new BitString that is identical to this BitString
    // except that the bit at position index is BinaryDigit.ONE
    public BitString set(int index)
    {
        return null;
    }

    //Returns a new BitString that is identical to this BitString
    // except that the bit at position index is BinaryDigit.ZRO
    public BitString clear(int index)
    {
        return null;
    }

    //Returns a new BitString that is identical to this BitString
    // except that the bit at position index is the complement of
    // the bit at position index of this BitString
    public BitString complement(int index)
    {
        return null;
    }

    //Returns a new BitString that is identical to this BitString
    // except that the bit at position index has been replaced by
    // the given (parameter) BinaryDigit digit
    public BitString assign(int index, BinaryDigit digit)
    {
        return null;
    }

    //IMAGES *****************************************************************

    //Returns an exact image of this BitString
    public String image()
    {
        return "";
    }

    //Override
    //Returns an image of this BitString with groups of 4 separated by a space
    public String toString()
    {
        return "";
    }
}